package com.example.profesor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfesorApplicationTests {

	@Test
	void contextLoads() {
	}

}
